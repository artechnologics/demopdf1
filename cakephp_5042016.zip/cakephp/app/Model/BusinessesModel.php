<?php
class BusinessesModel extends AppModel
{
	var $name ='Businesses';
	var $primaryKey='id';	
}
?>