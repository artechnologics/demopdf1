<?php
require_once('fpdf.php');
require_once('fpdi.php');
require_once('fpdf_tpl.php');

// Original file with multiple pages 
$fullPathToFile = "doc.pdf";

class PDF extends FPDI {

    var $_tplIdx;

    function Header() {

        global $fullPathToFile;

        if (is_null($this->_tplIdx)) {

            // THIS IS WHERE YOU GET THE NUMBER OF PAGES
            $this->numPages = $this->setSourceFile($fullPathToFile);
            $this->_tplIdx = $this->importPage(1);

        }
        $this->useTemplate($this->_tplIdx, 0, 0,200);

    }

    function Footer() {}

}

// initiate PDF
$pdf = new PDF();

// add a page
$pdf->AddPage();


// The new content
$pdf->SetFont("helvetica", "B", 25);
$pdf->SetTextColor(255, 0, 0);
$pdf->Text(40,120,"Sample Text over overlay");

// THIS PUTS THE REMAINDER OF THE PAGES IN
if($pdf->numPages>1) {
    for($i=2;$i<=$pdf->numPages;$i++) {
        //$pdf->endPage();
        $pdf->_tplIdx = $pdf->importPage($i);
        $pdf->AddPage();
    }
}

//show the PDF in page
//$pdf->Output();

// or Output the file as forced download
$pdf->Output("sampleUpdated.pdf", 'D');



 ?>
